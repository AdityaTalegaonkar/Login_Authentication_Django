from django.contrib import admin
from django.urls import path
from . import views 
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.User_Register,name='Register'),
    path('login/',views.Login,name='Login'),
    path('logout/',views.Logout,name='Logout'),
    path('user_profile/',views.User_display,name='user_profile'),
    path('change_password/',views.ChangePassword,name='ChangePassword'),
    path('forget_password/',views.ForgetPassword,name='ForgetPassword'),
]
# <token>]