from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,logout
from django.contrib import auth
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .email import send_forget_password_mail
from task_app.models import Profile
import uuid

# Create your views here.  superuser --> admin  pwd--> 123456

def User_Register(request):
    if request.method=='POST':
        name=request.POST['user_name']
        email_id=request.POST['email_id']
        password=request.POST['password']
        confirm_password = request.POST['confirm_password']
        if password!=confirm_password:
            messages.error(request,'Password did not match') 
        else: 
            user=User.objects.create_user(name,email_id,password)
            user.save()
            messages.success(request,'The Registration of ' +email_id+ ' succussfully done..!!')
            return redirect('login/')
    return render(request,'user_register.html')

def Login(request):
    if request.method=="POST":
        email_id=request.POST.get('email_id')
        pwd=request.POST.get('password')
        # print(email_id,pwd,'****')
        email_id_2 = User.objects.get(email=email_id.lower()).username
        # print(email_id_2,'=====')
        user = authenticate(request,username=email_id_2, password=pwd)
        print(user,'~~~~~~')
        user_id=request.user.id
        print(request.user.id)
        print(user_id,'%%%')
        if user is not None:
            auth.login(request,user)
            user_id=user.id
            return redirect('/user_profile')     
        else:
            print('$$$$')
            messages.error(request,'Email Id or Password Invalid')
    return render(request,'login.html')


@login_required(login_url='login')
def User_display(request):
    return render(request,'user_profile.html')

def Logout(request):
    print('####')
    logout(request)
    return render(request,'login.html')

def ChangePassword(request,token):
    context={}
    try:
        profile_obj=Profile.objects.filter(forget_password_token=token).first()
        context={'user_id':profile_obj.user_id}
        if request.method=='POST':
            password=request.POST.get('password')
            confirm_password=request.POST.get('newpassword')
            user_id=request.POST.get('user_id')

            if user_id is None:
                messages.success(request,'No User ID found')
                return redirect(f'/change_password/{token}')
            
            if confirm_password!=password:
                messages.success(request,'Both should be equal')
                return redirect(f'/change_password/{token}')
            
            user_obj=User.objects.get(id=user_id)
            user_obj.set_password(confirm_password)
            user_obj.save()
            return redirect('/login')

    except Exception as e:
        print(e)
    
    return render(request, 'change_password.html',context)

def ForgetPassword(request):
    try:
        if request.method=='POST':
            username =request.POST.get('name')
            if not User.objects.filter(username=username).first():
                messages.success(request,'Not user found with this username')
                return redirect('/forget_password')
            
            user_obj=User.objects.get(username=username)
            token=str(uuid.uuid4())
            profile_obj=Profile.objects.get(user=user_obj)
            profile_obj.forget_password_token=token
            profile_obj.save()
            send_forget_password_mail(user_obj,token)
            messages.success(request,'Email is Sent')
            return redirect('/forget_password')
            
    except Exception as e:
        print(e)


    return render(request,'forget_password.html')
